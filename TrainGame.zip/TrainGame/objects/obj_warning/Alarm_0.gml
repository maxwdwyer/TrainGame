alarm[1] = 10
image_xscale = 1.5
image_yscale = 1.5
