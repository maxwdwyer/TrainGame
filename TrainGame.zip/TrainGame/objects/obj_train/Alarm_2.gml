
instance_destroy(warning)